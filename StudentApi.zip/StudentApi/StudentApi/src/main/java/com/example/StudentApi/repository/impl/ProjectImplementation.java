package com.example.StudentApi.repository.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.StudentApi.entity.Project;
import com.example.StudentApi.repository.ProjectInterface;


@Repository
public class ProjectImplementation implements ProjectInterface {

	private static final String INSERTPROJECT = "INSERT INTO project VALUES (?,?,?,?,?)";
	private static final String FINDBYID = "SELECT * FROM project WHERE	project_id = ?";
	private static final String FINDALLPROJECTS = "SELECT * FROM project"; 
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	
	
	@Override
	public int save(Project project) throws Exception {
		
		return jdbcTemplate.update(INSERTPROJECT, 
				project.getProjectId(), project.getDurationInDays(), project.getEndDate(), project.getProjectName(), project.getStartDate());
	}

	
	@Override
	public Project findById(int projectid) {
		
		try {
			Project project =  jdbcTemplate.queryForObject(FINDBYID,
					BeanPropertyRowMapper.newInstance(Project.class), projectid);

				return project;							//add logic for valid projectid
		}catch(EmptyResultDataAccessException e) {
			return null;
//			throw new ProjectNotFoundException();
		}
		
	}

	
	@Override
	public List<Project> findAll() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query( FINDALLPROJECTS,
				BeanPropertyRowMapper.newInstance(Project.class));
	}

}
