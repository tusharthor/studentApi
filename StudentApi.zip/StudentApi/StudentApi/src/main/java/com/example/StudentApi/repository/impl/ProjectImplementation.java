package com.example.StudentApi.repository.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.StudentApi.entity.Project;
import com.example.StudentApi.repository.ProjectInterface;


@Repository
public class ProjectImplementation implements ProjectInterface {

	private static final String INSERTPROJECT = "INSERT INTO project (project_id, project_name, duration_in_days, start_date, end_date) VALUES (?,?,?,?,?)";
	private static final String FINDBYID = "SELECT * FROM project WHERE	project_id = ?";
	private static final String FINDALLPROJECTS = "SELECT * FROM project"; 
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	
	
	@Override
	public int save(Project project) throws Exception {
		
		return jdbcTemplate.update(INSERTPROJECT, 
				project.getProjectId(), project.getProjectName(), project.getDurationInDays(), project.getStartDate(), project.getEndDate());
	}

	
	@Override
	public Project findById(int projectid) {
		
		try {
			Project project =  jdbcTemplate.queryForObject(FINDBYID,
					BeanPropertyRowMapper.newInstance(Project.class), projectid);
			
			return project;
		}catch(DataAccessException d) {
			return null;
		}
		
	}

	
	@Override
	public List<Project> findAll() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query( FINDALLPROJECTS,
				BeanPropertyRowMapper.newInstance(Project.class));
	}

}
