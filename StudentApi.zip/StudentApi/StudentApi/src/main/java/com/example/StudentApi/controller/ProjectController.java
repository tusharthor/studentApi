package com.example.StudentApi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.StudentApi.entity.Project;
import com.example.StudentApi.repository.ProjectInterface;

@RestController
public class ProjectController {
	
	@Autowired
	ProjectInterface projectInterface;
	
	
	@GetMapping("/projects")
	public List<Project> getAllProjects(){
		return projectInterface.findAll();
	}

	
	@PostMapping("/project/insert")
	public String insertProject(@RequestBody Project project) {
		
		try {
			projectInterface.save(new Project(project.getProjectId(), project.getProjectName(), project.getDurationInDays(),
					project.getStartDate(), project.getEndDate()));
			
			return "project added";
		}catch(Exception e) {
			return e.getMessage();
		}
	}
}
