package com.example.StudentApi.repository;

import java.util.List;

import com.example.StudentApi.entity.Student;

public interface StudentInterface {

	int save(Student student) throws Exception;
	
	Student findById(int studentId);
	
	List<Student> findAll();
}
