package com.example.StudentApi.entity;

import java.util.Date;


public class Project {
	
	
	private int project_id;
	private String projectName;
	private int durationInDays;
	private Date startDate;
	private Date endDate;
	
		
	public Project() {}
	
	public Project(int projectId, String projectName, int durationInDays, Date startDate, Date endDate) {
		super();
		this.project_id = projectId;
		this.projectName = projectName;
		this.durationInDays = durationInDays;
		this.startDate = startDate;
		this.endDate = endDate;
	}
	
	public int getProjectId() {
		return project_id;
	}
	public void setProjectId(int projectId) {
		this.project_id = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public int getDurationInDays() {
		return durationInDays;
	}
	public void setDurationInDays(int durationInDays) {
		this.durationInDays = durationInDays;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	
	@Override
	public String toString() {
		return "Project [projectId=" + project_id + ", projectName=" + projectName + ", durationInDays=" + durationInDays
				+ ", startDate=" + startDate + ", endDate=" + endDate + "]";
	}
	
	
}
