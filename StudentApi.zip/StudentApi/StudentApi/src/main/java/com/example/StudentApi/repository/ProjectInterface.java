package com.example.StudentApi.repository;

import java.util.List;

import com.example.StudentApi.entity.Project;

public interface ProjectInterface {

	int save(Project project) throws Exception;
	
	Project findById(int projectId);
	
	List<Project> findAll();
}
