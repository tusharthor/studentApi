package com.example.StudentApi.controller;

public class StudentController {

}
