package com.example.StudentApi.controller;

import java.util.List;
import java.util.regex.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.StudentApi.entity.Student;
import com.example.StudentApi.repository.StudentInterface;

@RestController
public class StudentController {

	@Autowired
	StudentInterface studentInterface;
	
	@GetMapping("/students")
	public List<Student> getAllProjects(){
		return studentInterface.findAll();
	}

	
	@PostMapping("/student/insert")
	public String insertStudent(@RequestBody Student student) {
		
		try {
			String regex = "^[A-Za-z0-9+_.-]+@(.+)$";
			String emailValidate = student.getEmailId();
			
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(emailValidate);
			
			if(matcher.matches())
			{
				studentInterface.save(new Student(student.getStudentId(), student.getFirstName(), student.getLastName(),
						student.getMobileNumber(), student.getEmailId()));
				return "Student Added";
			}
			else {
				return "please enter valid email id";
			}
			
			
		}catch(Exception e) {
			return e.getMessage();
		}
	}
	
	@GetMapping("/student/{studentId}")
	public Student getStudentById(@PathVariable int studentId) {
		return studentInterface.findById(studentId);
	}
}
