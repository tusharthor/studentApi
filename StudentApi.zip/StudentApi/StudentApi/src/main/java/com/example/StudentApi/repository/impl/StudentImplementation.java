package com.example.StudentApi.repository.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.StudentApi.entity.Student;
import com.example.StudentApi.repository.StudentInterface;


@Repository
public class StudentImplementation implements StudentInterface{

	private static final String INSERTSTUDENT = "INSERT INTO student VALUES (?,?,?,?,?)";
	private static final String FINDBYID = "SELECT * FROM student WHERE	student_id = ?";
	private static final String FINDALLSTUDENTS = "SELECT * FROM student"; 
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	
	
	@Override
	public int save(Student student) throws Exception {
		
		return jdbcTemplate.update(INSERTSTUDENT,
				student.getStudentId(), student.getFirstName(), student.getLastName(), student.getMobileNumber(), student.getEmailId()); 
				
	}

	
	@Override
	public Student findById(int studentid) {
		
		try {
			
			Student student =  jdbcTemplate.queryForObject(FINDBYID,
					BeanPropertyRowMapper.newInstance(Student.class), studentid);
			
			return student;						//add logic for valid studentId 
		}catch(DataAccessException d) {
			return null;
		}
		
	}

	
	@Override
	public List<Student> findAll() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query( FINDALLSTUDENTS,
				BeanPropertyRowMapper.newInstance(Student.class));
	}

}
